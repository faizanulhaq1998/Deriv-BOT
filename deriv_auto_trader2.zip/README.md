GitHub Upload Instructions:
1. Unzip this folder.
2. Open GitHub > New Repository.
3. Upload all files.
4. Settings > Pages > Deploy from branch.
5. Select main branch and root.
6. Wait for deployment.
